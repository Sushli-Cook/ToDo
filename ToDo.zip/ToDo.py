import tkinter as tk


def add():
    aufgabe = eingabe.get().strip()
    if aufgabe:
        liste.insert(tk.END, aufgabe)
        eingabe.delete(0, tk.END)


root = tk.Tk()
root.title("To-Do List")
root.geometry("300x300")

eingabe = tk.Entry(root, width=25)
eingabe.pack(pady=10)

hinzufuegen_btn = tk.Button(
    root, text="Add", command=add)
hinzufuegen_btn.pack()


liste = tk.Listbox(root, width=40, height=10)
liste.pack(pady=10)

root.mainloop()
